Publshr — macOS native desktop installer
========================================

WHAT YOU GET
  • Publshr.app — Swift/SwiftUI IDE (not a web app or Electron shell)
  • Auto-updates from GitHub after the first install

OPTION A — Double-click (easiest)
  1. Unzip this folder
  2. Double-click "Publshr Install.command"
  3. Follow the native Installer window, or allow Terminal to install to Applications
  4. Publshr opens when finished

OPTION B — Terminal (one line)
  curl -fsSL "https://raw.githubusercontent.com/hiagoccss-svg/publshr.exe/refs/heads/main/install-macos.sh" | bash

OPTION C — Run the script in this folder
  bash install-macos.sh

REQUIREMENTS
  • macOS 14 or later (Apple Silicon recommended)
  • Internet access to download the app (~5–15 MB from GitHub)
  • Administrator password for /Applications (one time)

AFTER INSTALL
  • App: /Applications/Publshr.app
  • Updates: automatic from the "live" release (no reinstall needed)

Full app package (advanced / offline): see GitHub Releases → Publshr-macos-aarch64.tar.gz
